#include "../include/server.hpp"


int main() {
	Server server(16088);
	server.work();
}