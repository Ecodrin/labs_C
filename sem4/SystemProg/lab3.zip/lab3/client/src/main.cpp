#include "client.hpp"


int main() {
	Client client(16088, "127.0.0.1");
	client.work();


}